package com.ems.util;

public abstract class InvalidNameException extends RuntimeException {
	public InvalidNameException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
	

}
