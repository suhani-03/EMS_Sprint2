package com.ems.util;

public class InvalidDobException extends RuntimeException {
	public InvalidDobException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
